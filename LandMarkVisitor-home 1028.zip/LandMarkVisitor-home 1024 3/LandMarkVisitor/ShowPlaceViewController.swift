//
//  ShowPlaceViewController.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/18.
//

import UIKit
import CoreData
protocol  ShowPlaceViewControllerDelegate : AnyObject {
     func clickDelete()
}

class ShowPlaceViewController: UIViewController {

    weak var delegate : UploadViewControllerDelegate?

    weak var delegate2 : ShowPlaceViewControllerDelegate?
    
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbLocation: UILabel!
    @IBOutlet weak var lbLevel: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    
    var priority = PriorityLevel.init(rawValue: 5)
    var selectedTodoList : TodoList?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    var todolist = [TodoList]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbLevel.backgroundColor = .clear
    }
    
    func setLevel(level : Int64) -> String{
        switch level{
        case 0:
            return "😍"
        case 1:
            return "😊"
        case 2:
            return "😳"
        case 3:
            return "😔"
        case 4:
            return "🤬"
        default:
            return ""
        }
        
    }
    
    func setColor(level : Int64) -> UIColor{
        switch level{
        case 0:
            return .systemBlue
        case 1:
            return .systemGreen
        case 2:
            return .systemYellow
        case 3:
            return .systemOrange
        case 4:
            return .systemRed
        default:
            return .black
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let hasData = selectedTodoList{
            lbTitle.text = hasData.title
            lbLocation.text = hasData.location
            lbDescription.text = hasData.detail

            lbLevel.text = setLevel(level: hasData.priorityLevel)
            lbLevel.backgroundColor = setColor(level: hasData.priorityLevel)
     
        }
        if let hasDate = selectedTodoList?.date{
                    let formatter = DateFormatter()
                    
                    formatter.dateFormat = "YYYY-MM-dd"
                    let dataString = formatter.string(from: hasDate)
            lbDate.text = dataString
                    
                    
        }
        if let hasImage =
            selectedTodoList?.image{
            imageview.image = UIImage(data: hasImage)
        }
    }

    @IBAction func btnClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func btnDelete(_ sender: Any) {
        deleteTodo()
    }
    
    func deleteTodo(){
        
        guard let hasData = selectedTodoList else{
            return
        }
        
        guard let hasUUID = hasData.uuid else{
            return
        }
        
        let fetchRequest: NSFetchRequest <TodoList> = TodoList.fetchRequest()
        
        fetchRequest.predicate = NSPredicate(format: "uuid = %@", hasUUID as CVarArg)
        
        do{
            let loadedData = try context.fetch(fetchRequest)
            
            if let loadFirstData = loadedData.first{
                context.delete(hasData)
                let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
                appDelegate.saveContext()
                
                
                
            }
        }catch{
            print(error)
        }
        
        delegate?.didFinishSaveData()
        delegate2?.clickDelete()
        self.dismiss(animated: true)
    }
}

