//
//  ParsingTestViewController.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/25.
//

import UIKit
import SwiftSoup

class ParsingTestViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var locationLabel: UILabel!
    
    @IBOutlet weak var contentLable: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    @IBOutlet weak var placeImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        crawl()
        //crawl2()
//        crawl3()
        crawl5(urlAddress: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4")
    }

    func crawl(){
        let url = URL(string: "https://www.aladin.co.kr/shop/common/wbest.aspx?BranchType=1&start=we")
        
        guard let myURL = url else {   return    }
        
        do {
            let html = try String(contentsOf: myURL, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            let headerTitle = try doc.title()
            print(headerTitle)
            
            let firstLinkTitles:Elements = try doc.select(".bo3").select("b") //.은 클래스
            for i in firstLinkTitles {
                print("title: ", try i.text())
            }
            
            
        } catch Exception.Error(let type, let message) {
            print("Message: \(message)")
        } catch {
            print("error")
        }
        
    }
    
    func crawl2(){
        let url = URL(string: "https://www.aladin.co.kr/shop/common/wbest.aspx?BranchType=7")
        
        guard let myURL = url else {   return    }
        
        do {
            let html = try String(contentsOf: myURL, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            let headerTitle = try doc.title()
            print(headerTitle)
            
            let firstLinkTitles:Elements = try doc.select(".bo3").select("b") //.은 클래스
            for i in firstLinkTitles {
                print("title: ", try i.text())

            }
            
            
        } catch Exception.Error(let type, let message) {
            print("Message: \(message)")
        } catch {
            print("error")
        }
    }
    
    
    @IBAction func btnCR(_ sender: Any) {
        crawl5(urlAddress: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121")
        
    }
    func crawl4(urlAddress : String)  -> String{
        
        var tt = ""

        let url = URL(string: urlAddress)
        DispatchQueue.global().async {
            do {
                let html = try String(contentsOf: url!, encoding : .utf8)
                let doc : Document = try SwiftSoup.parse(html)

                let title : Elements = try doc.select(".Fc1rA")
                let location : Elements = try doc.select(".IH7VW")
                let contents : Elements = try doc.select(".DJJvD")
                let phoneNumber : Elements = try doc.select(".dry01")
//
//
//                let imagesrc : Elements = try doc.select(".K0PDV _div")
//                let stringImage = try imagesrc.attr("src").description
//                let urlImage = URL(string: stringImage)
//                let data = try Data(contentsOf: urlImage!)
//                self.placeImage.image = UIImage(data: data) // UI 세팅

                
                let imagesrc: Elements = try doc.select(".K0PDV _div")
                    //.select("background_image").select("url")
                    //.select("ibu1")

                let stringImage = try imagesrc.attr("src").description

                let urlImage = URL(string: stringImage)


                let data = try Data(contentsOf: urlImage!)

                self.placeImage.image = UIImage(data: data) // UI 세팅
                
                
                for i in title {
                    print("title: ", try i.text())
                    tt = try i.text()
                    self.titleLabel.text = try i.text()
                }
                for i in location{
                    print("location: ", try i.text())
                }
                for i in contents{
                    print("contents: ", try i.text())
                }
                for i in phoneNumber{
                    print("phoneNumber: ", try i.text())
                }
                
            } catch let error {
                print(error)
            }
        }
        return tt
    }
    
    func crawl5(urlAddress : String)  -> String{
        
        //var urlArray = Array<Int64>()
        
        
        let url = URL(string: urlAddress)
        DispatchQueue.global().async {
            
            //var urlArray : [String]
            //var arrnum = 0
            
            var title: Elements = Elements()
            var location: Elements = Elements()
            var contents = Elements()
            var phoneNumber = Elements()
            var imagesrc = Elements()
            do {
                let html = try String(contentsOf: url!, encoding : .utf8)
                let doc : Document = try SwiftSoup.parse(html)

                title = try doc.select(".Fc1rA")
                location = try doc.select(".IH7VW")
                contents = try doc.select(".DJJvD")
                phoneNumber = try doc.select(".dry01")

                imagesrc = try doc.select(".BkqXt").select(".K0PDV")
                
                for i in imagesrc {
                    let stringImage = try i.attr("style").description
                    print(stringImage.split(separator: "\"")[1])
                    let stringItem = stringImage.split(separator: "\"")[1]
                    print(stringItem)
                    
                    
                    
                    //urlArray[arrnum] = String(string)
//                    arrnum = arrnum + 1
                }
//

//                self.placeImage.image = UIImage(data: data) // UI 세팅
            } catch let error {
                print(error)
            }
            DispatchQueue.main.async { [weak self] in
                for i in title {
                    self?.titleLabel.text = try! i.text()
                }
                for i in location{
                    self?.locationLabel.text = try! i.text()

                }
                for i in contents{
                    self?.contentLable.text = try! i.text()
                }
                for i in phoneNumber{
                    self?.phoneNumberLabel.text = try! i.text()

                }
                for i in imagesrc{
                    let stringImage = try i.attr("style").description
                    print(stringImage.split(separator: "\"")[1])
                    let stringItem = stringImage.split(separator: "\"")[1]
                    print(stringItem)
                    let urlImage = URL(string: stringImage)
                    let data = try Data(contentsOf: urlImage!)
                    self?.placeImage.image = UIImage(data: data)
                }
                //for i in 
            }
        }
        return "hello world"
    }
    
}
