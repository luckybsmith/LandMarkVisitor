//
//  DetailViewController.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/23.
//

import UIKit
import SwiftSoup
import CoreData


protocol DetailViewControllerDelegate : AnyObject {
    func clickDelete()
}

class DetailViewController: UIViewController,UIScrollViewDelegate {
        
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbLocation: UILabel!
    @IBOutlet weak var lbContents: UILabel!
    @IBOutlet weak var lbPhoneNumber: UILabel!
    
    @IBOutlet weak var btnSaveImage: UIBarButtonItem!
    
    
    var images = [UIImage]()
    var imageViews = [UIImageView]()
    var urlAddress : String = ""
    var saveBtnImg = UIImage()
    var saveBtnMode : String = "save"
    
    var selectedTodoList : PlaceList?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    weak var delegate : DetailViewControllerDelegate?

    let appdelegate = UIApplication.shared.delegate as! AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        print("url Address : ",urlAddress)
        crawling(urlAddress: urlAddress)
        setting()
        makeBtnDelete()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //crawling(urlAddress: urlAddress)

    }
    
    func setting(){
        addContentScrollView()
        setPageControl()
        scrollView.delegate = self
        scrollView.contentMode = .scaleAspectFill
    }
    @IBAction func btnBack(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func crawling(urlAddress : String){
        

        let url = URL(string: urlAddress)
        var array = Array<Data>()
            do {
                let html = try String(contentsOf: url!, encoding : .utf8)
                let doc : Document = try SwiftSoup.parse(html)

                let title : Elements = try doc.select(".Fc1rA")
                let location : Elements = try doc.select(".IH7VW")
                let contents : Elements = try doc.select(".DJJvD")
                let phoneNumber : Elements = try doc.select(".dry01")
                let imagesrc = try doc.select(".BkqXt").select(".K0PDV")


                for i in title {
                    lbTitle.text = try i.text()
                    print("title: ", try i.text())
                }
                for i in location{
                    lbLocation.text = try i.text()
                    print("location: ", try i.text())

                }
                for i in contents{
                    lbContents.text = try i.text()
                    print("contents: ", try i.text())
                }
                for i in phoneNumber{
                    lbPhoneNumber.text = try i.text()
                    print("phoneNumber: ", try i.text())

                }
                
                for i in imagesrc {
                    let stringImage = try i.attr("style").description
                    //get string
                    let stringItem = String(stringImage.split(separator: "\"")[1])
                    //get url
                    let urlImage = URL(string: stringItem)
                    //get data
                    let data = try Data(contentsOf: urlImage!)
                    //get image
                    self.images.append(UIImage(data: data)!)


                    array.append(data)
                    print(array.count)
                }
   
            } catch let error {
                print(error)
            }
    }
    
    private func addContentScrollView() {
            
            for i in 0..<images.count {
                let imageView = UIImageView()
                let xPos = scrollView.frame.width * CGFloat(i)
                imageView.frame = CGRect(x: xPos, y: 0, width: scrollView.bounds.width, height: scrollView.bounds.height)
                imageView.image = images[i]
                imageView.contentMode = .scaleAspectFit
                scrollView.addSubview(imageView)
                scrollView.contentSize.width = imageView.frame.width * CGFloat(i + 1)
                scrollView.contentSize.height = imageView.frame.height
            }
            
        }
        
    private func setPageControl() {
            pageControl.numberOfPages = images.count
            
    }
        
    private func setPageControlSelectedPage(currentPage:Int) {
            pageControl.currentPage = currentPage
    }
        
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
            let value = scrollView.contentOffset.x/scrollView.frame.size.width
            setPageControlSelectedPage(currentPage: Int(round(value)))
    }
    
  
    func saveData(){
        guard let entityDescription = NSEntityDescription.entity(forEntityName: "PlaceList", in: context) else {return}
        
        guard let object = NSManagedObject(entity: entityDescription, insertInto: context) as? PlaceList else {return}
        //what is context
        
        object.url = urlAddress
        object.title = lbTitle.text
        //priority
        let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
        appDelegate.saveContext()
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
       
        
        do {
            try context.save()
        } catch let error {
            print(error.localizedDescription)
        }
    
  
        
    }
    
    @IBAction func btnSave(_ sender: Any) {
        if saveBtnMode == "save"{
            btnSaveImage.image = UIImage(systemName: "square.and.arrow.down.fill")
            saveData()}
        else{
            deleteData()
            print("delete")
        }
    }
    
    func makeBtnDelete(){
        if saveBtnMode == "delete"{
            btnSaveImage.image = UIImage(systemName: "delete.left")
        }
    }
    func deleteData(){
        guard let hasData = selectedTodoList else{
            return
        }
        guard let hasUUID = hasData.uuid else{
            return
        }

        let fetchRequest: NSFetchRequest <PlaceList> = PlaceList.fetchRequest()

        fetchRequest.predicate = NSPredicate(format: "uuid = %@", hasUUID as CVarArg)

        do{
            let loadedData = try context.fetch(fetchRequest)

            if let loadFirstData = loadedData.first{
                context.delete(hasData)
                let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
                appDelegate.saveContext()
            }
        }catch{
            print(error)
        }

        delegate?.clickDelete()
        
        self.dismiss(animated: true)
    }
}
