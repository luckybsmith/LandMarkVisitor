//
//  ViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/07/12.
//

import UIKit

class MainViewController : UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //크롤링해서 데이터 저장시킴
}


