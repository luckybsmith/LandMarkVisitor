//
//  SeoulAreaViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/08/22.
//

import UIKit

class SeoulAreaCell : UITableViewCell {
    @IBOutlet weak var SeoulAreaLabel: UILabel!
    //self.selectionStyle = .none
    
    @IBOutlet weak var TypeLabel: UILabel!
}
class SeoulAreaViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource{
//    var placeName: [String]!
//    var url: [String]!
//    var sections : [String]!
    struct Place {
        var title: String
        var type : String
        var url: String
    }
    
    let Sungsu = [
        Place(title: "연무장", type: "카페",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%B9%B4%ED%8E%98+%EC%97%B0%EB%AC%B4%EC%9E%A5&oquery=%EC%97%B0%EB%AC%B4%EC%9E%A5&tqi=h2viJsprvxZsslo%2F4f8ssssstuw-247188"),
        Place(title: "오우드", type: "카페",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%98%A4%EC%9A%B0%EB%93%9C&oquery=%EC%98%A4%EC%9A%B0%EB%93%9C&tqi=h2vj7sprvhGssikE75VssssstlK-324405"),
        Place(title: "Scene", type: "카페",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98+scene&oquery=%EC%84%B1%EC%88%98%EB%8F%99+scene&tqi=h2vjSlprvOsssR5DttsssssstF4-016807"),
        Place(title: "디플렛", type: "카페",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98+%EB%94%94%ED%94%8C%EB%A0%9B&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98+scene&tqi=h2vjTlprvOsssR7v4d4ssssst2w-240393"),
        Place(title: "어니언 성수", type: "카페", url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EC%96%B4%EB%8B%88%EC%96%B8+"),
        Place(title: "LOWIDE", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++lowide&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++lowede&tqi=h2vkUwprvh8ssMx7TDsssssst8s-455631"),
        Place(title: "서울앵무새", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EC%84%9C%EC%9A%B8%EC%95%B5%EB%AC%B4%EC%83%88&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++lowide&tqi=h2vkidprvTVssccO7c0ssssssi8-507968"),
        Place(title: "멜로워 성수 더 플래그쉽", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EB%A9%9C%EB%A1%9C%EC%9B%8C&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EC%84%9C%EC%9A%B8%EC%95%B5%EB%AC%B4%EC%83%88&tqi=h2vkIlprvxZsslXmE6ssssssssl-139900"),
        Place(title: "블루보틀 성수", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EB%B8%94%EB%A3%A8%EB%B3%B4%ED%8B%80&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EB%A9%9C%EB%A1%9C%EC%9B%8C&tqi=h2vNvsprvxsssCQ8StKssssst88-035653"),
        Place(title: "누데이크", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EB%88%84%EB%8D%B0%EC%9D%B4%ED%81%AC+%EC%84%B1%EC%88%98%EC%A0%90&oquery=%EC%84%B1%EC%88%98%EB%8F%99+%EC%B9%B4%ED%8E%98++%EB%88%84%EB%8D%B0%EC%9D%B4%ED%81%AC&tqi=h2vNlsprvhGssijZZtZsssssshR-098319"),
        Place(title: "에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
        Place(title: "루프", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%B9%B4%ED%8E%98++%EB%A3%A8%ED%94%84&oquery=%EC%84%B1%EC%88%98+%EB%A3%A8%ED%94%84&tqi=h2vOcdprvxsssCe8HQhssssssad-157302")
       //Place(title: <#T##String#>, type: "카페", url: <#T##String#>)
        
    ].sorted { $0.title < $1.title }
    let Hannam = [Place(title: "카페/에이투비 Cafe&Ba", type: "식당", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),]
    
    
    let Sinsa = [Place(title: "카페/에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
                 ]
    
    let Bukchon = [Place(title: "카페/에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
                  ]
    
    let Hongdae = [Place(title: "카페/에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
                   ]
    
    let EulJiro = [Place(title: "카페/에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
                   ]
    
    let yongsan = [Place(title: "카페/에이투비 Cafe&Ba", type: "카페", url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EC%84%B1%EC%88%98+%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&oquery=%EC%97%90%EC%9D%B4%ED%88%AC%EB%B9%84&tqi=h2vNplprvOsssg9BnywssssstI8-254081"),
                   ]
    
    let sections = ["성수/서울숲", "한남","입구정/신사","북촌/서촌","홍대/연남동/연희동","을지로","해방촌"] //7개
        
    override func viewDidLoad() {
        super.viewDidLoad()
        URLData.sharedInstance.placeType = .seoul
//        placeName = URLData.sharedInstance.placeNames()
//        url = URLData.sharedInstance.url()
        
    }
    
    //섹션갯수
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    //섹션출력
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }
    //row갯수
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0)
        {
            return Sungsu.count
        }
        return Hannam.count
    }
    //섹션 내 셀 구성
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SeoulAreaCell_ID", for: indexPath) as! SeoulAreaCell
    
        if indexPath.section == 0{
            cell.SeoulAreaLabel.text = Sungsu[indexPath.row].title
            cell.TypeLabel.text = Sungsu[indexPath.row].type
        }else if indexPath.section == 1{
            cell.SeoulAreaLabel.text = Hannam[indexPath.row].title
            cell.TypeLabel.text = Hannam[indexPath.row].type

        }else if indexPath.section == 2{
            cell.SeoulAreaLabel.text = Sinsa[indexPath.row].title
            cell.TypeLabel.text = Sinsa[indexPath.row].type

        }else if indexPath.section == 3{
            cell.SeoulAreaLabel.text = Bukchon[indexPath.row].title
            cell.TypeLabel.text = Bukchon[indexPath.row].type

        }else if indexPath.section == 4{
            cell.SeoulAreaLabel.text = Hongdae[indexPath.row].title
            cell.TypeLabel.text = Hongdae[indexPath.row].type

        }else if indexPath.section == 5{
            cell.SeoulAreaLabel.text = EulJiro[indexPath.row].title
            cell.TypeLabel.text = EulJiro[indexPath.row].type

        }else if indexPath.section == 6{
            cell.SeoulAreaLabel.text = yongsan[indexPath.row].title
            cell.TypeLabel.text = yongsan[indexPath.row].type

        }
        return cell
    }
    //테이블뷰 눌렀을 때
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                let showVC = DetailViewController(nibName: "DetailViewController", bundle: nil)
                showVC.modalPresentationStyle = .fullScreen
                showVC.urlAddress = Sungsu[indexPath.row].url
        showVC.cityType = "Seoul"
        
        if indexPath.section == 0 {
            showVC.urlAddress = Sungsu[indexPath.row].url
            showVC.areatype = "Sungsu"
        } else if indexPath.section == 1 {
            showVC.urlAddress = Hannam[indexPath.row].url
            showVC.areatype = "Hannam"
        } else if indexPath.section == 2 {
            showVC.urlAddress = Sinsa[indexPath.row].url
            showVC.areatype = "Sinsa"
        }else if indexPath.section == 3 {
            showVC.urlAddress = Bukchon[indexPath.row].url
            showVC.areatype = "Bukchon"
        }else if indexPath.section == 4 {
            showVC.urlAddress = Hongdae[indexPath.row].url
            showVC.areatype = "Hongdae"
        }else if indexPath.section == 5 {
            showVC.urlAddress = EulJiro[indexPath.row].url
            showVC.areatype = "EulJiro"
        }else if indexPath.section == 6 {
            showVC.urlAddress = yongsan[indexPath.row].url
            showVC.areatype = "yongsan"
        }
        self.present(showVC,animated: true)

    }
 

   
    
}


