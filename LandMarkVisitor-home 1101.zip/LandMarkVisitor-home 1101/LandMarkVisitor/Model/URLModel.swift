//
//  URLModel.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/11/01.
//

import Foundation
class URLData {
    
    static var sharedInstance = URLData()
    
    enum Place {
        case seoul, busan, jeju
    }
    
    enum SeoulArea {
        case sungsu, hannam , sinsa , bukchon , hongdae , euljiro , yongsan
    }
    
    struct PlaceModel {
        var title: String
        var url: String
    }
    
    var placeType: Place = .seoul
    
    private var sections : [String]?
    private var placeNameList: [String]?
    private var urlList: [String]?

//    func makeModel() -> PlaceModel{
//        switch SeoulArea {
//        case .sungsu:
//            PlaceModel = [
//                Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
//                Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
//                Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
//                Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")
//            ]
//        case .hannam:
//        case .sinsa:
//        case .bukchon:
//        case .hongdae:
//        case .euljiro:
//        case .yongsan:
//    }
    
    func section() -> [String] {
        switch placeType {
        case .seoul:
            sections = ["성수/서울숲", "한남","입구정/신사","북촌/서촌","홍대/연남동/연희동","을지로","해방촌"]
        case .busan:
            sections = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
        case .jeju:
            sections = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
        }
        
        return sections ?? []
    }
    
    func placeNames() -> [String] {
        switch placeType {
        case .seoul:
            placeNameList = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
        case .busan:
            placeNameList = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
        case .jeju:
            placeNameList = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
        }
        
        return placeNameList ?? []
    }
    
    func url() -> [String] {
        switch placeType {
        case .seoul:
            urlList = ["https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4",
                   "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=0&acr=1&acq=%EB%8D%94%ED%98%84&qdt=0&ie=utf8&query=%EB%8D%94%ED%98%84%EB%8C%80%EC%84%9C%EC%9A%B8"
            ]
        case .busan:
            urlList = ["https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4",
                   "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=0&acr=1&acq=%EB%8D%94%ED%98%84&qdt=0&ie=utf8&query=%EB%8D%94%ED%98%84%EB%8C%80%EC%84%9C%EC%9A%B8"
            ]
        case .jeju:
            urlList = ["https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4",
                   "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4",
                   "https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=0&acr=1&acq=%EB%8D%94%ED%98%84&qdt=0&ie=utf8&query=%EB%8D%94%ED%98%84%EB%8C%80%EC%84%9C%EC%9A%B8"
            ]
        }
        
        return urlList ?? []
    }
    
    
}
