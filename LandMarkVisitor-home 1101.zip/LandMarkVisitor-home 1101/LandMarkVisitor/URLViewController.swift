//
//  URLViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/11/01.
//

import UIKit
class MyTableViewCell : UITableViewCell{
        
    @IBOutlet weak var nameLabel: UILabel!
    
}
class URLViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    
    struct Place {
        var title: String
        var url: String
    }
    
    let Sungsu = [
        Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
        Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
        Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
        Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")
    ]
    let Hannam = [
        Place(title: "김철수",url: "kim@gmail.com"),
        Place(title: "안철수",url: "ahn@gmail.com"),
        Place(title: "고길동",url: "gogo@gmail.com"),
        Place(title: "백종원",url: "backback@gmail.com")
    ]
    
    let Sinsa = [Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
                 Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
                 Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
                 Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")]
    let Bukchon = [Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
                   Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
                   Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
                   Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")]
    let Hongdae = [Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
                   Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
                   Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
                   Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")]
    let EulJiro = [Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
                   Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
                   Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
                   Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")]
    let Yongsam = [Place(title: "스태픽스",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4"),
                   Place(title: "경복궁",url: "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121"),
                   Place(title: "스타벅스 광운대점",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90"),
                   Place(title: "로로옴",url: "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4")]
    
    let sections = ["성수/서울숲", "한남","입구정/신사","북촌/서촌","홍대/연남동/연희동","을지로","해방촌"] //7개
    
    @IBOutlet weak var myTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.delegate = self
        myTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    //섹션갯수
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    //섹션출력
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }
    //row갯수
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0)
        {
            return Sungsu.count
        }
        return Hannam.count
    }
    //섹션 내 셀 구성
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MyTableViewCell = self.myTableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyTableViewCell
        
        if( indexPath.section == 0 )
        {
            cell.nameLabel.text = Sungsu[indexPath.row].title
        }else{
            cell.nameLabel.text = Hannam[indexPath.row].title
        }
        return cell
    }
    //테이블뷰 눌렀을 때
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                let showVC = DetailViewController(nibName: "DetailViewController", bundle: nil)
                showVC.modalPresentationStyle = .fullScreen
                showVC.urlAddress = Sungsu[indexPath.row].url
        
        
        if indexPath.section == 0 {
            showVC.urlAddress = Sungsu[indexPath.row].url
        } else if indexPath.section == 1 {
            showVC.urlAddress = Hannam[indexPath.row].url
        } else if indexPath.section == 2 {
            showVC.urlAddress = Sungsu[indexPath.row].url
        }
        self.present(showVC,animated: true)

    }
}
