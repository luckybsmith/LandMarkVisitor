//
//  BusanAreaViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/08/22.
//

import UIKit

class BusanAreaCell : UITableViewCell {
    
    @IBOutlet weak var BusanAreaLabel: UILabel!
}
class BusanAreaViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource{
    var placeName = ["스태픽스","경복궁","스타벅스 광운대점","로로옴","더현대 서울 여의도"]
    var url = ["https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=1&acr=1&ie=utf8&query=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4",
               "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EA%B2%BD%EB%B3%B5%EA%B6%81&oquery=%EC%8A%A4%ED%83%9C%ED%94%BD%EC%8A%A4&tqi=h1Aurwp0JXossjVF6BKssssstSK-213121",
               "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EC%8A%A4%ED%83%80%EB%B2%85%EC%8A%A4+%EA%B4%91%EC%9A%B4%EB%8C%80%EC%A0%90",
               "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%A1%9C%EB%A1%9C%EC%98%B4",
               "https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=0&acr=1&acq=%EB%8D%94%ED%98%84&qdt=0&ie=utf8&query=%EB%8D%94%ED%98%84%EB%8C%80%EC%84%9C%EC%9A%B8"
  ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.url.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BusanAreaCell_ID", for: indexPath) as! BusanAreaCell
        
        cell.BusanAreaLabel.text = placeName[indexPath.row]

        
        cell.selectionStyle = .none
        return cell
    }


    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //didSelectRowAt - 눌렀을 때
        //todolist[indexPath.row]
        
        let showVC = DetailViewController(nibName: "DetailViewController", bundle: nil)
        //showVC.selectedTodoList = todolist[indexPath.row]
        showVC.modalPresentationStyle = .fullScreen
        //showVC.delegate2 = self
        showVC.urlAddress = url[indexPath.row]
        self.present(showVC,animated: true)
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()


    }
    

}
