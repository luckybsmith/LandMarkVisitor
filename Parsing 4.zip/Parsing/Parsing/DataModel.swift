//
//  DataModel.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/28.
//

import Foundation
//크롤링 할 url

struct naverPlace{
    let name : String
    let location : String
    let contents : String
   
}
