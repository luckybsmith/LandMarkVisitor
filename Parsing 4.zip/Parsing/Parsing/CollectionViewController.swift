//
//  CollectionViewController.swift
//  Parsing
//
//  Created by 이송은 on 2022/10/28.
//

import UIKit
import PhotosUI

class PhotoCell : UICollectionViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!{
        didSet{
            photoImageView.contentMode = .scaleAspectFill
        }
    }
    func loadImage(asset : PHAsset){
        let imageManager = PHImageManager()
        let scale = UIScreen.main.scale
        let imageSize = CGSize(width: 150 * scale, height: 150 * scale)
        
        
        imageManager.requestImage(for: asset, targetSize: imageSize, contentMode: .aspectFill, options: nil) { image, info in
            self.photoImageView.image = image
        }
    }
}
class CollectionViewController: UIViewController {
    
    var fetchResults : PHFetchResult<PHAsset>?
    
    @IBOutlet weak var photoCollectionView: UICollectionView!
    @IBOutlet weak var album: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        let layout = UICollectionViewFlowLayout()
//        layout.itemSize = CGSize(width: 200, height: 200)
        layout.itemSize = CGSize(width: (UIScreen.main.bounds.width - 1 ) / 2 , height: 200)
        layout.minimumInteritemSpacing = 1
        layout.minimumLineSpacing = 1
        photoCollectionView.collectionViewLayout = layout
    }
    
    @IBAction func goAlbum(_ sender: Any) {
        checkPermission()
    }
    
    @IBAction func refresh(_ sender: Any) {
        self.photoCollectionView.reloadData()
    }
    
    func checkPermission(){
        if PHPhotoLibrary.authorizationStatus() == .authorized || PHPhotoLibrary.authorizationStatus() == .limited{
            DispatchQueue.main.async {
                self.showGallery()
            }
        }
        else if PHPhotoLibrary.authorizationStatus() == .denied{
            DispatchQueue.main.async {
                self.goSettingAlert()

            }
        }
        else if PHPhotoLibrary.authorizationStatus() == .notDetermined{
            PHPhotoLibrary.requestAuthorization { status in
                self.checkPermission()
            }
        }
    }
    
    func goSettingAlert(){
        let alert = UIAlertController(title: "접근 권한 필요", message: "", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "닫기", style: .cancel))
        alert.addAction(UIAlertAction(title: "설정으로 가기", style: .default, handler: {
            action in
            guard let url = URL(string : UIApplication.openSettingsURLString) else{return}
            if UIApplication.shared.canOpenURL(url){
                UIApplication.shared.open(url)
            }
        }))
        
        self.present(alert, animated: true)
    }
    func showGallery(){
        let library = PHPhotoLibrary.shared()
        var configuration = PHPickerConfiguration(photoLibrary: library)
        configuration.selectionLimit = 10
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
        
    }
}

extension CollectionViewController : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.fetchResults?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
        
        if let asset = self.fetchResults?[indexPath.row]{
            cell.loadImage(asset: asset)
        }
        
        return cell
    }
    
    
    
}

extension CollectionViewController : PHPickerViewControllerDelegate{
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        let identifiers = results.map{
            $0.assetIdentifier ?? ""}
        self.fetchResults = PHAsset.fetchAssets(withLocalIdentifiers: identifiers, options: nil)
        self.photoCollectionView.reloadData()
        self.dismiss(animated: true)
    }
    
    
}
