//
//  MyPageViewController.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/15.
//

import UIKit
import CoreData

enum PriorityLevel : Int64{
    case level1
    case level2
    case level3
    case level4
    case level5
}
extension PriorityLevel{
    var color : UIColor{
        switch self {
        case .level1:
            return .green
        case .level2:
            return .orange
        case .level3:
            return .red
            
        case .level4:
            return .blue
        case .level5:
            return .systemPink
        }
    }
}
//extension PriorityLevel{
//    var level : String{
//        switch self{
//        case .level1 :
//            return "😍"
//        case .level2:
//            return "😘"
//        case .level3:
//            return "🙂"
//        case .level4:
//            return "😔"
//        case .level5:
//            return "🤬"
//        default :
//            break
//        }
//    }
//
//}
class MyPageCell : UITableViewCell {
    
    @IBOutlet weak var lbLevel: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lbLocation: UILabel!
}
class MyPageViewController: UIViewController {
    
    
    @IBOutlet weak var tableview: UITableView!
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    var todolist = [TodoList]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeNavi()

        fetchData()
        tableview.reloadData()
    }
    
    
    func fetchData(){
        
        let fetchrequest : NSFetchRequest<TodoList> = TodoList.fetchRequest()
        //데이터 가져오기
        let context = appdelegate.persistentContainer.viewContext
        
        
        do {
            self.todolist = try context.fetch(fetchrequest)
            
        }catch{
            print(error)
        }
    }
    
    
    
    @objc func addNewTodo(){
        print("add")
        let detailVC = UploadViewController.init(nibName: "UploadViewController", bundle: nil)
        detailVC.delegate = self
        self.present(detailVC, animated: true)
        
    }

    
    func makeNavi(){
        let item = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewTodo))
        navigationItem.rightBarButtonItem = item
    }
}


extension MyPageViewController : UITableViewDelegate , UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.todolist.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyPageCell", for: indexPath) as! MyPageCell
        
        cell.lblName.text = todolist[indexPath.row].title
        cell.lbLocation.text = todolist[indexPath.row].location
        if let hasDate = todolist[indexPath.row].date{
            let formatter = DateFormatter()
            
            formatter.dateFormat = "MM-dd hh:mm:ss"
            let dataString = formatter.string(from: hasDate)
            
//            cell.topTitle.text = dataString
            
        }
        else{
//            cell.topTitle.text = ""
        }
        
        let priority = todolist[indexPath.row].priorityLevel
        let priorityColor = PriorityLevel(rawValue: priority)?.color
//        cell.priorityView.backgroundColor = priorityColor
//        cell.priorityView.layer.cornerRadius = cell.priorityView.bounds.height/2
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //didSelectRowAt - 눌렀을 때
        todolist[indexPath.row]
        let detailVC = UploadViewController(nibName:"UploadViewController", bundle: nil)

        //let detailVC = UpLoadViewController.init(nibName: "UpLoadViewController", bundle: nil)
        detailVC.delegate = self
        detailVC.selectedTodoList = todolist[indexPath.row]

        self.present(detailVC, animated: true)
        
        
    
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}


extension MyPageViewController : UploadViewControllerDelegate {
    func didFinishSaveData() {
        self.fetchData()
        self.tableview.reloadData()
    }
    
    
}
