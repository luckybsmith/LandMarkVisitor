//
//  UpLoadViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/10/17.
//

import UIKit
import CoreData

protocol UploadViewControllerDelegate : AnyObject{
    func didFinishSaveData()
}

class UploadViewController: UIViewController {
    
    weak var delegate : UploadViewControllerDelegate?
    
    @IBOutlet weak var btnLevel1: UIButton!
    
    @IBOutlet weak var btnLevel2: UIButton!
    
    @IBOutlet weak var btnLevel3: UIButton!
    @IBOutlet weak var btnLevel4: UIButton!
    
    @IBOutlet weak var btnLevel5: UIButton!
    
    @IBOutlet weak var titleTF: UITextField!
    
    @IBOutlet weak var locationTF: UITextField!
    @IBOutlet weak var detailTF: UITextField!
    
    @IBOutlet weak var btnSave: UIButton!
    
    @IBOutlet weak var btnDelete: UIButton!
    
    
    var priority = PriorityLevel.init(rawValue: 0)
    var selectedTodoList : TodoList?

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let hasData = selectedTodoList{
            titleTF.text = hasData.title
            locationTF.text = hasData.location
            priority = PriorityLevel(rawValue: hasData.priorityLevel)
            btnDelete.isHidden = false
            btnSave.setTitle("update", for: .normal)
        }else{
            btnDelete.isHidden = true
            btnSave.setTitle("save", for: .normal)
        }
        
        
    }
    @IBAction func LevelClick(_ sender: UIButton) {
        
            switch sender.tag{
            case 1:
                print("1")
                priority = .level1
            case 2:
                print("2")
                priority = .level2
            case 3:
                print("3")
                priority = .level3
            case 4:
                print("4")
                priority = .level4
            case 5:
                print("5")
                priority = .level5
            default :
                break
            }
            makePriorityBtn()
            
        
        
    }
        
        func makePriorityBtn(){
            
            //        switch self.priority{
            //        case .level1:
            //            var level1Label : String = "😍"
            //            btnLevel1.setTitle(level1Label, for: .normal)
            //        case .level2:
            //            var level2Label : String = "😘"
            //            btnLevel2.setTitle(level2Label, for: .normal)
            //        case .level3:
            //            var level3Label : String = "🙂"
            //            btnLevel3.setTitle(level3Label, for: .normal)
            //        case .level4:
            //            var level4Label : String = "😔"
            //            btnLevel4.setTitle(level4Label, for: .normal)
            //        case .level5:
            //            var level5Label : String = "🤬"
            //            btnLevel5.setTitle(level5Label, for: .normal)
            //        default:
            //            break
            //        }
            
            
            switch self.priority{
            case .level1:
                btnLevel1.backgroundColor = priority?.color
            case .level2:
                btnLevel2.backgroundColor = priority?.color
            case .level3:
                btnLevel3.backgroundColor = priority?.color
            default:
                break
            }
            
            
        }
        
        
        
        @IBAction func btnSave(_ sender: Any) {
            
            if selectedTodoList != nil{
                updateTodo()
            }else{
                saveTodo()
            }
            
            delegate?.didFinishSaveData()
            self.dismiss(animated: true)
        }
        
        @IBAction func btnDelete(_ sender: Any) {
            deleteTodo()
        }
        
        func saveTodo(){
            //data
            
            guard let entityDescription = NSEntityDescription.entity(forEntityName: "TodoList", in: context) else {return}
            
            guard let object = NSManagedObject(entity: entityDescription, insertInto: context) as? TodoList else {return}
            //what is context
            
            object.title = titleTF.text
            object.location = locationTF.text
            object.date = Date()
            object.uuid = UUID()
            
            object.priorityLevel = priority?.rawValue ?? PriorityLevel.level1.rawValue
            
            
            //priority
            let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
            appDelegate.saveContext()
            
        }
        
        func updateTodo(){
            
            guard let hasData = selectedTodoList else{
                return
            }
            
            guard let hasUUID = hasData.uuid else{
                return
            }
            
            let fetchRequest: NSFetchRequest <TodoList> = TodoList.fetchRequest()
            
            fetchRequest.predicate = NSPredicate(format: "uuid = %@", hasUUID as CVarArg)
            
            do{
                let loadedData = try context.fetch(fetchRequest)
                loadedData.first?.title = titleTF.text
                loadedData.first?.location = locationTF.text
                loadedData.first?.date = Date()
                loadedData.first?.priorityLevel = self.priority?.rawValue ?? PriorityLevel.level1.rawValue
                
                let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
                appDelegate.saveContext()
                
            }catch{
                print(error)
            }
        }
        
        func deleteTodo(){
            
            guard let hasData = selectedTodoList else{
                return
            }
            
            guard let hasUUID = hasData.uuid else{
                return
            }
            
            let fetchRequest: NSFetchRequest <TodoList> = TodoList.fetchRequest()
            
            fetchRequest.predicate = NSPredicate(format: "uuid = %@", hasUUID as CVarArg)
            
            do{
                let loadedData = try context.fetch(fetchRequest)
                
                if let loadFirstData = loadedData.first{
                    context.delete(hasData)
                    let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
                    appDelegate.saveContext()
                }
            }catch{
                print(error)
            }
            
            delegate?.didFinishSaveData()
            self.dismiss(animated: true)
            
        }
        
    
}
