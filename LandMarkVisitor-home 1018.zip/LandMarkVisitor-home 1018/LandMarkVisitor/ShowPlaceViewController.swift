//
//  ShowPlaceViewController.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/18.
//

import UIKit
import CoreData

class ShowPlaceViewController: UIViewController {

    weak var delegate : UploadViewControllerDelegate?

    
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbLocation: UILabel!
    @IBOutlet weak var lbLevel: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    @IBOutlet weak var lbDescription: UILabel!
    
    var priority = PriorityLevel.init(rawValue: 0)
    var selectedTodoList : TodoList?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    var todolist = [TodoList]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let hasData = selectedTodoList{
            lbTitle.text = hasData.title
            lbLocation.text = hasData.location
            lbDescription.text = hasData.description
            
            
        }
    }

    @IBAction func btnClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func btnDelete(_ sender: Any) {
        deleteTodo()
    }
    
    func deleteTodo(){
        
        guard let hasData = selectedTodoList else{
            return
        }
        
        guard let hasUUID = hasData.uuid else{
            return
        }
        
        let fetchRequest: NSFetchRequest <TodoList> = TodoList.fetchRequest()
        
        fetchRequest.predicate = NSPredicate(format: "uuid = %@", hasUUID as CVarArg)
        
        do{
            let loadedData = try context.fetch(fetchRequest)
            
            if let loadFirstData = loadedData.first{
                context.delete(hasData)
                let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
                appDelegate.saveContext()
                
                
                
            }
        }catch{
            print(error)
        }
        
        delegate?.didFinishSaveData()
        self.dismiss(animated: true)
    }
}
