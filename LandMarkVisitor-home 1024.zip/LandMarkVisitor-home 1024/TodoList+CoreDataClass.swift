//
//  TodoList+CoreDataClass.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/22.
//
//

import Foundation
import CoreData

@objc(TodoList)
public class TodoList: NSManagedObject {

}
