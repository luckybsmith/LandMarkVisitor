//
//  DetailViewController.swift
//  LandMarkVisitor
//
//  Created by Leesongeun on 2022/10/23.
//

import UIKit
import SwiftSoup
import MapKit

class DetailViewController: UIViewController {

    @IBOutlet weak var myMap: MKMapView!
    
    var urlstring = ""
    var location = "서울 종로구 사직로 161 경복궁"
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    @IBAction func btnBack(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func crawling(urlAddress : String){
        

        let url = URL(string: urlAddress)
            do {
                let html = try String(contentsOf: url!, encoding : .utf8)
                let doc : Document = try SwiftSoup.parse(html)

                let title : Elements = try doc.select(".Fc1rA")
                let location : Elements = try doc.select(".IH7VW")
                let contents : Elements = try doc.select(".DJJvD")
                let phoneNumber : Elements = try doc.select(".dry01")

//
//                let imagesrc : Elements = try doc.select(".K0PDV _div")
//                let stringImage = try imagesrc.attr("src").description
//                let urlImage = URL(string: stringImage)
//                let data = try Data(contentsOf: urlImage!)
//                self.placeImage.image = UIImage(data: data) // UI 세팅

                for i in title {
                    print("title: ", try i.text())
                }
                for i in location{
                    print("location: ", try i.text())

                }
                for i in contents{
                    print("contents: ", try i.text())
                }
                for i in phoneNumber{
                    print("phoneNumber: ", try i.text())

                }
            } catch let error {
                print(error)
            }
    }
}
