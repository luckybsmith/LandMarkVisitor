//
//  SeoulAreaViewController.swift
//  LandMarkVisitor
//
//  Created by 이송은 on 2022/08/22.
//

import UIKit

class SeoulAreaCell : UITableViewCell {
    @IBOutlet weak var SeoulAreaLabel: UILabel!
    
}
class SeoulAreaViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource{
    
    struct SeoulAreaDataModel{
        var description : String
        var isExpand : Bool
    }
    
    var dataModels = [SeoulAreaDataModel]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SeoulAreaCell_ID", for: indexPath) as! SeoulAreaCell
        
        cell.SeoulAreaLabel.text = dataModels[indexPath.row].description
        
        if dataModels[indexPath.row].isExpand == true {
            cell.SeoulAreaLabel.numberOfLines = 0
        }else{
            cell.SeoulAreaLabel.numberOfLines = 1
        }
        
        cell.selectionStyle = .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //didSelectRowAt - 눌렀을 때
        //todolist[indexPath.row]
        
        let showVC = DetailViewController(nibName: "DetailViewController", bundle: nil)
        //showVC.selectedTodoList = todolist[indexPath.row]
        showVC.modalPresentationStyle = .fullScreen
        //showVC.delegate2 = self
        self.present(showVC,animated: true)
        
    }
    
    var SeoulAreaArray = ["안국역/경복궁","경복궁역/스태픽스"]
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        dataModels[indexPath.row].isExpand = !dataModels[indexPath.row].isExpand
//
//        tableView.reloadRows(at: [indexPath], with: .none)
//    }

    override func viewDidLoad() {
        super.viewDidLoad()

        for (_,value) in SeoulAreaArray.enumerated() {
            dataModels.append(SeoulAreaDataModel.init(description: value, isExpand: false))
        }

    }
    
}
